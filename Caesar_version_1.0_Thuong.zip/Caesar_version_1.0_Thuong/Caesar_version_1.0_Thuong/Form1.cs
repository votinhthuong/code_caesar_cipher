﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Caesar_version_1._0_Thuong
{
    public partial class Caesar_Cipher_Thuong : Form
    {
        public Caesar_Cipher_Thuong()
        {
            InitializeComponent();
        }
        //=====================Author: Vo Tinh Thuong=====================//
        //=====================Email: votinhthuong9@gmail.com=====================//
        //=====================Blog: minhthuongeh.wordpress.com=====================//
        //=====================Website: votinhthuong.net=====================//
        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            
            for (int i = 1; i <= 25; i++)
                comboBox1.Items.Add(i);

            comboBox1.SelectedIndex = 12;
        }
        //=====================Author: Vo Tinh Thuong=====================//
        //=====================Email: votinhthuong9@gmail.com=====================//
        //=====================Blog: minhthuongeh.wordpress.com=====================//
        //=====================Website: votinhthuong.net=====================//
        private void btn_encrypt_Click(object sender, EventArgs e)
        {
            txt_decrypt.Clear();
            int rot = Convert.ToInt32(comboBox1.SelectedItem);
            string output = "";
            string array = txt_plaintext.Text;
            int t1 = 0;
            foreach (char c in array)
            {
                if ((int)c == 32 || ((int)c >= 48 && (int)c <= 57))
                    t1 = c;
                else if (((int)c >= 0 && (int)c <= 31) ||
                    ((int)c >= 33 && (int)c <= 47) ||
                    ((int)c >= 58 && (int)c <= 64) ||
                    ((int)c >= 91 && (int)c <= 96) ||
                    ((int)c >= 123 && (int)c <= 127))
                    t1 = c;
                else if ((int)c>=97 && (int)c<=122)
                    t1 = (((int)c - 97 + rot) % 26) + 97;
                else if ((int)c >= 65 && (int)c <= 90)
                    t1 = (((int)c - 65 + rot) % 26) + 65;
                output += (char)t1;
            }
            txt_encrypt.Text = output;
        }
        //=====================Author: Vo Tinh Thuong=====================//
        //=====================Email: votinhthuong9@gmail.com=====================//
        //=====================Blog: minhthuongeh.wordpress.com=====================//
        //=====================Website: votinhthuong.net=====================//
        private void btn_decrypt_Click(object sender, EventArgs e)
        {
            txt_encrypt.Clear();
            int rot = Convert.ToInt32(comboBox1.SelectedItem);
            string output = "";
            string array = txt_plaintext.Text;
            int t1 = 0;
            foreach (char c in array)
            {
                if ((int)c == 32 || ((int)c >= 48 && (int)c <= 57))
                    t1 = c;
                else if (((int)c >= 0 && (int)c <= 31) ||
                    ((int)c >= 33 && (int)c <= 47) ||
                    ((int)c >= 58 && (int)c <= 64) ||
                    ((int)c >= 91 && (int)c <= 96) ||
                    ((int)c >= 123 && (int)c <= 127))
                    t1 = c;
                else if ((int)c >= 97 && (int)c <= 122)
                    t1 = ((((int)c - 97) - rot + 26) % 26) + 97;
                else if ((int)c >= 65 && (int)c <= 90)
                    t1 = ((((int)c - 65) - rot + 26) % 26) + 65;
                output += (char)t1;
            }
            txt_decrypt.Text = output;
        }
        //=====================Author: Vo Tinh Thuong=====================//
        //=====================Email: votinhthuong9@gmail.com=====================//
        //=====================Blog: minhthuongeh.wordpress.com=====================//
        //=====================Website: votinhthuong.net=====================//
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
